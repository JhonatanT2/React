import React, {useState} from 'react';
import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

import Card from 'react-bootstrap/Card';

 const Inicio = () => {
  const [personajes, setPersonajes]=useState ([]);
  
  useEffect( () =>{
    fetchDatos();
  }, []);

  const fetchDatos = async () =>{
    try{
        const url = "https://swapi.dev/api/people";
        const respuesta = await fetch(url);
        const json = await respuesta.json();
        console.log(json);
        setPersonajes(json.results);
    
    }
    catch (error){
        console.log("error: "+error);
    }
  }
  const img= "https://starwars-visualguide.com/assets/img/characters/";
  return (<>
    <h1 className='text-center'>Personajes Star Wars</h1>
    <div data="characters" class="row">
        {personajes.map(({name},i) =>
           // <li id={`personaje${i}`} key={name}> <Link to={`Posts/${id}`}><img src={`${img}/${i+1}.jpg`} /></Link> </li>
           <Card style={{ width: '18rem' }}>
                <Link to={`Info/${i+1}`}>
                    <img class="card-img-top" id={`personaje${i}`} key={name} src={`${img}/${i+1}.jpg`}/>
                    <p class="lead">{name}</p>
                </Link>
            </Card>
        )}
      </div>
    </>
  )
}
export default Inicio;



