import React, {useState} from 'react';
import Card from 'react-bootstrap/Card';
import { useEffect } from 'react';
import ListGroup from 'react-bootstrap/ListGroup';
import ListGroupItem from 'react-bootstrap/esm/ListGroupItem';
import { Link } from 'react-router-dom';


const Ficha = (props) => {
  const [url, setUrl]=useState ("");
  const [detalle, setDetalle]=useState ("");
  
  useEffect( () =>{
    fetchDatos();
  }, []);

  const fetchDatos = async () =>{
    try{
        const respuesta = await fetch(url);
        const json = await respuesta.json();
        console.log(json);
        setDetalle(json.title);
    
    }
    catch (error){
        console.log("error: "+error);
    }
  }


  return (
    <Card className='col-4'>
      <Card.Body>
        <Card.Title> {props.nombre} </Card.Title>
      </Card.Body>
        
        <ListGroup> 
          {props.datos!==undefined && props.datos.length > 0 ?  props.datos.map(
            dato =>{
              // setUrl(dato);

            return (
              <Link>{dato}</Link>       
            )
          }
          ): <p>No hay elemnts</p>
        }
        </ListGroup>
        {/* <Card.Text>

        </Card.Text> */}
    </Card>
  )
}

export default Ficha;